package com.wifiaudit.poc

import android.Manifest
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun WiFiScannerScreen() {
    val context = LocalContext.current
    val scanner = remember { WiFiScanner(context) }
    
    var networks by remember { mutableStateOf<List<WiFiNetwork>>(emptyList()) }
    var isScanning by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    
    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE
        )
    )
    
    fun performScan() {
        isScanning = true
        statusMessage = "Scanning..."
        try {
            networks = scanner.scanNetworks()
            val vulnerableCount = networks.count { it.isVulnerable }
            statusMessage = "Found ${networks.size} networks ($vulnerableCount vulnerable)"
        } catch (e: Exception) {
            statusMessage = "Scan failed: ${e.message}"
        } finally {
            isScanning = false
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WiFi Security Audit PoC") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (permissionsState.allPermissionsGranted) {
                        performScan()
                    } else {
                        permissionsState.launchMultiplePermissionRequest()
                    }
                },
                icon = { Icon(Icons.Default.Refresh, "Scan") },
                text = { Text("Scan") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Permission status
            if (!permissionsState.allPermissionsGranted) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Permissions Required",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("This app needs location and WiFi permissions to scan networks.")
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = { permissionsState.launchMultiplePermissionRequest() }) {
                            Text("Grant Permissions")
                        }
                    }
                }
            }
            
            // Status message
            if (statusMessage.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = statusMessage,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            
            // Loading indicator
            if (isScanning) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(modifier = Modifier.padding(16.dp))
                }
            }
            
            // Networks list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(networks) { network ->
                    NetworkCard(
                        network = network,
                        onConnect = { net ->
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                scanner.connectToNetwork(
                                    network = net,
                                    onSuccess = { statusMessage = "Connected to ${net.ssid}" },
                                    onFailure = { error -> statusMessage = error }
                                )
                            } else {
                                statusMessage = "Auto-connect requires Android 10+"
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun NetworkCard(
    network: WiFiNetwork,
    onConnect: (WiFiNetwork) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (network.isVulnerable) 
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
            else 
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = null,
                        tint = if (network.isVulnerable) Color.Red else Color.Gray
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = network.ssid,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = network.bssid,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
                
                if (network.isVulnerable) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Vulnerable",
                        tint = Color.Red
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Signal strength
            Text(
                text = "Signal: ${"▮".repeat(network.signalStrength)}${"▯".repeat(5 - network.signalStrength)}",
                style = MaterialTheme.typography.bodySmall
            )
            
            if (network.isVulnerable) {
                Spacer(modifier = Modifier.height(8.dp))
                
                Surface(
                    color = MaterialTheme.colorScheme.error,
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = "VULNERABLE - ${network.vulnerabilityType?.name}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Generated Password: ${network.generatedPassword}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = { onConnect(network) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Connect / Test")
                }
            }
        }
    }
}
